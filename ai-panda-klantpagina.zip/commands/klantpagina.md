---
description: Genereer een AI Panda klantpagina in Notion
allowed-tools: Read, Write, Bash, Grep, Glob, WebFetch, WebSearch, AskUserQuestion, TodoWrite, mcp__claude_ai_Notion__notion-create-pages, mcp__claude_ai_Notion__notion-fetch, mcp__claude_ai_Gamma__generate, mcp__claude_ai_Gamma__get_themes
---

**ALLEREERSTE ACTIE — schrijf dit direct als je eerste output, nog VOORDAT je iets anders doet:**

Hey Panda! Even geduld, ik start de klantpagina-wizard...

---

Voer daarna de klantpagina-v2 skill uit, stap voor stap, beginnend bij **Stap 1 (vraag om bedrijf)**.
