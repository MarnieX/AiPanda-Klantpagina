---
description: Genereer een AI Panda klantpagina in Notion
allowed-tools: Read, Write, Bash, Grep, Glob, WebFetch, WebSearch, AskUserQuestion, TodoWrite, mcp__claude_ai_Notion__notion-create-pages, mcp__claude_ai_Notion__notion-fetch
---

**ALLEREERSTE ACTIE — schrijf dit direct als je eerste output, nog VOORDAT je iets anders doet:**

Hey Panda! 🐼 Even geduld, ik start de klantpagina-wizard...

---

Voer daarna de klantpagina skill uit, stap voor stap, beginnend bij **Stap 0 (health check)**.
