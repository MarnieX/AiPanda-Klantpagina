---
description: Genereer een AI Panda klantpagina in Notion
allowed-tools: Read, Write, Bash, Grep, Glob, WebFetch, WebSearch, AskUserQuestion, TodoWrite, mcp__claude_ai_Notion__notion-create-pages, mcp__claude_ai_Notion__notion-fetch
---

Start de AI Panda Klantpagina Generator wizard. Volg de instructies in de klantpagina skill exact.

Begin bij Stap 1: vraag de gebruiker voor welk bedrijf de klantpagina moet worden aangemaakt.
