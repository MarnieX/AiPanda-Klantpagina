---
name: ai-toekomstvisie
description: >
  Genereer een visionair AI-toekomstbeeld voor een (potentiële) klant: een inspirerend 10-jaar
  transformatieverhaal dat laat zien hoe hun bedrijf er in de toekomst uit kan zien dankzij AI,
  aangevuld met een gebrandde afbeelding-prompt en een update van hun Notion-klantpagina.

  Gebruik deze skill wanneer iemand vraagt om een toekomstvisie, AI-roadmap, of klantpresentatie
  te maken rondom AI-transformatie. Trigger ook bij: "maak een visie voor [klant]",
  "hoe ziet [bedrijf] er over 10 jaar uit met AI", "toekomstvisie genereren", of wanneer
  een Notion-klantpagina URL wordt meegegeven met de vraag iets inspirerends te maken.
---

# AI Toekomstvisie

## Doel

Deze skill helpt eBlaze om potentiële klanten een concreet en inspirerend beeld te geven van
hoe hun bedrijf er over 10 jaar uit kan zien wanneer ze AI volledig omarmen. Het eindresultaat
is een aansprekend verhaal + visueel beeld, toegevoegd aan de bestaande Notion-klantpagina.

Het effect dat je wilt bereiken: de klant leest het en denkt "dit zijn wij — en zo willen we zijn."
Specifiek, herkenbaar, ambitieus maar geloofwaardig. Visionair, niet slechts een optimalisatie
van wat vandaag al bestaat.

## Wat je nodig hebt van de gebruiker

Voordat je begint, zorg dat je het volgende hebt:
- **Klantnaam** — naam van het bedrijf
- **Notion-pagina URL** — de bestaande klantpagina waar de visie aan toegevoegd wordt

Een beschrijving is **niet** vereist van de gebruiker — je zoekt die zelf op (zie Stap 1).

Als de Notion-URL ontbreekt, vraag er dan eerst naar.

## Werkwijze

Volg deze stappen in volgorde.

### Stap 1: Research (altijd doen, automatisch)

Doe dit altijd, zonder te vragen aan de gebruiker. Voer parallel uit:

**a) Bedrijfswebsite bezoeken**
Zoek via WebSearch naar de officiële website van het bedrijf. Fetch dan:
- De homepage
- De "Over ons" of "Diensten" pagina
- Eventuele pagina over duurzaamheid, missie of toekomstvisie

Doel: begrijpen wat ze doen, voor wie, hoe ze zichzelf positioneren, en wat hun toon is.

**b) Huisstijl en merkidentiteit achterhalen**
Bekijk de website ook visueel (via WebFetch). Let op:
- Primaire en secundaire merkkleur(en) — inclusief hex-codes indien zichtbaar
- Lettertype en typografische stijl
- Tagline of pay-off
- Kenmerkende visuele elementen (voertuigen, uniformen, logo-stijl, fotografie-stijl)
- Sfeer van de beeldtaal: zakelijk, warm, technisch, menselijk?

Noteer deze merkkenmerken expliciet — je hebt ze nodig voor de afbeelding-prompt.

**c) Sectorprobleem identificeren**
Zoek via WebSearch naar het grootste structurele probleem in de sector van dit bedrijf
dat AI de komende 10 jaar kan oplossen. Denk niet aan kleine efficiëntiewinsten —
zoek naar fundamentele knelpunten die de hele sector raken (capaciteitstekorten,
informatiefragmentatie, veiligheidsvraagstukken, regulatoire complexiteit, etc.).

Dit wordt de kern van het transformatieverhaal.

**d) Notion-pagina lezen**
Fetch de opgegeven Notion-pagina om te begrijpen:
- Welke context er al is over de klant
- Wat de toon van de pagina is
- Wat er onderaan de pagina staat (zodat je de juiste `insert_content_after`-ankertekst weet)

### Stap 2: Het 10-jaar transformatieverhaal schrijven

Schrijf een visionair verhaal van **350–500 woorden** in de taal die past bij de klant
(standaard Nederlands, tenzij de Notion-pagina in het Engels is).

**Structuur** — schrijf als doorlopend proza, geen kopjes of bullets:

1. **Opening met een persoon** — Begin met een concreet, levendig beeld van één medewerker
   op een gewone werkdag in [huidig jaar + 10]. Wie is dit? Wat doet ze? Wat ziet ze?
   Maak het zo specifiek dat het voelt als een scène, niet als een beschrijving.

2. **Het sectorprobleem dat opgelost is** — Laat zien hoe het centrale sectorprobleem
   (gevonden in Stap 1c) er destijds uitzag en hoe AI dat nu fundamenteel heeft opgelost.
   Dit is het visionaire hart: niet "processen zijn efficiënter", maar een echte
   structurele verschuiving die 10 jaar geleden ondenkbaar was.

3. **Bedrijfsbrede transformatie** — Zoom uit naar het bedrijf als geheel. Hoe staat
   het er voor in de markt? Wat kunnen ze nu wat niemand anders kan? Hoe ziet de
   klantrelatie eruit? Wat is er structureel anders dan bij concurrenten?

4. **Terug naar de mens** — Eindig bij de persoon uit de opening. Hoe ervaart zij
   haar werk? Wat heeft de transformatie voor háár betekend? Kort, concreet, menselijk.

**Toon**: Warm, zelfverzekerd, visionair — alsof je een blik in de toekomst gooit die
*geloofwaardig aanvoelt*. Niet wollig of generiek. Niet vol jargon. Geen sciencefiction.
Ambitieus maar aards.

**Visionair betekent**: dingen beschrijven die vandaag de dag nog niet bestaan of
niet op deze schaal werken. Denk aan: autonome systemen die namens honderden klanten
tegelijk onderhandelen, AI die sectorbrede coördinatieproblemen oplost, nieuwe
samenwerkingsvormen die door AI mogelijk worden, diensten die vijf jaar geleden
conceptueel ondenkbaar waren.

**Wat je vermijdt**:
- Generieke uitspraken die voor elk bedrijf gelden ("AI maakt processen efficiënter")
- Dingen die vandaag al bestaan en als toekomstvisie worden gepresenteerd
- Opsommingen of bullets — het moet een verhaal zijn
- Techno-utopisme dat de menselijke kern mist

### Stap 3: Gebrandde afbeelding-prompt schrijven

Schrijf een gedetailleerde prompt in het Engels voor een AI-beeldgenerator. Deze prompt
komt **niet** in de Notion-pagina zelf — die wordt afgehandeld via de Gemini MCP tool.
Sla de prompt op zodat je hem klaar hebt voor Stap 4 (de placeholder) en Stap 5.

De afbeelding moet onmiskenbaar van dit bedrijf zijn. Verwerk daarom altijd:
- **Merkkleur(en)** als dominant of sterk aanwezig kleuraccent (gebruik de hex-codes)
- **Kenmerkende visuele elementen** van het merk: logo op kleding of voertuigen,
  herkenbare uniformen, bedrijfsvoertuigen, gebouwen of materialen die bij het bedrijf horen
- **Tagline of wordmark** subtiel maar zichtbaar in de scène (op een muur, raam, of object)
- **Sfeer die past bij de merkidentiteit**: warm en familiair, strak en technisch,
  of juist avontuurlijk — afhankelijk van wat de website uitstraalt

Aanvullende eisen:
- **Stijl**: hyperrealistisch, fotografisch, 8K, cinematische diepte
- **Persoon centraal**: een herkenbare medewerker in beeld, niet abstract
- **Natuur + technologie + bedrijf in synergie**: natuur is aanwezig maar ondersteunend,
  nooit de hoofdtoon — denk aan groene daken buiten het raam, een plantenwand op de achtergrond,
  zonlicht dat door bomen valt terwijl de technologie op de voorgrond staat
- **Geen clichés**: geen robotarmen, geen blauwe hologrammen, geen Matrix-visuals,
  geen stockfoto-poses

### Stap 4: Notion-pagina aanmaken

Maak een nieuwe pagina aan via `notion-create-pages` (zonder parent — technische beperking)
met de volgende vaste structuur. Gebruik altijd deze volgorde:

**1. Paginatitel — prikkelend en specifiek**
Niet "AI Toekomstvisie 2035" maar een titel die de kern van de transformatie benoemt.
Denk aan de vorm: *"Hoe [bedrijf] in 2035 [wat bereikt] zonder [wat het vroeger kostte]"*
of een krachtige bewering die de lezer nieuwsgierig maakt. Specifiek voor dit bedrijf.

**2. Pull quote — bovenaan, los van de tekst**
De slotquote van de persoon uit het verhaal, als blockquote. Dit is het eerste dat de lezer ziet
na de titel. Formaat:
```
> "[De slotquote van de hoofdpersoon, letterlijk uit het verhaal]"
>
> — [Naam], [functie] bij [bedrijf], 2035
```

**3. Het verhaal — doorlopend proza**
De volledige verhaaltekst, zonder tussenkoppen of bullets.

**4. Afbeeldingsplaceholder**
Een callout-blok dat aangeeft waar de Gemini-afbeelding komt:
```
> 🖼️ *Afbeelding volgt — gegenereerd via Gemini op basis van merkprompt.*
```

**5. Kerngetallen — vier callout-blokken**
Vier feitelijke highlights uit het verhaal als losse callouts, elk op een eigen regel.
Kies getallen en feiten die écht in het verhaal voorkomen. Formaat:
```
> [emoji] **[getal of feit]** — [korte duiding]
> [emoji] **[getal of feit]** — [korte duiding]
> [emoji] **[getal of feit]** — [korte duiding]
> [emoji] **[getal of feit]** — [korte duiding]
```

Kies passende emoji's op basis van het thema (🛤️ voor infra, ⚡ voor energie, etc.).

### Stap 5: Terugkoppeling aan gebruiker

Meld kort:
1. Dat de pagina is aangemaakt (geef de URL) en dat hij naar de juiste plek gesleept kan worden
2. Geef de afbeelding-prompt weer in de chat zodat die via Gemini gebruikt kan worden
3. Benoem kort welk sectorprobleem je als kern hebt gekozen

## Kwaliteitscheck

Stel jezelf deze vragen voordat je de Notion-pagina aanmaakt:

- Is de **paginatitel** specifiek en prikkelend — niet generiek?
- Is het verhaal **specifiek voor dit bedrijf**, of had ik het ook voor een concurrent kunnen schrijven?
- Beschrijft het verhaal iets wat **vandaag nog niet bestaat** — niet slechts een betere versie van nu?
- Zit het **centrale sectorprobleem** erin verwerkt als de eigenlijke doorbraak?
- Is de **persoon** uit de opening ook terug in de pull quote bovenaan?
- Komen de **kerngetallen** letterlijk voor in het verhaal — zijn ze niet verzonnen?
- Bevat de afbeelding-prompt de **merkkleur, het logo/wordmark, en kenmerkende visuele elementen**?
- Is de **natuur aanwezig maar niet dominant** in de afbeelding?

Als één van deze vragen nee is: herschrijf eerst.
